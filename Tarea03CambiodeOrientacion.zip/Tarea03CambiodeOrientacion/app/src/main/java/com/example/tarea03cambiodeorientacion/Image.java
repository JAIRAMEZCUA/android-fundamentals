package com.example.tarea03cambiodeorientacion;

public class Image {
    int ImageResource;

    public Image(int imageResource) {
        ImageResource = imageResource;
    }

    public int getImageResource() {
        return ImageResource;
    }
}
